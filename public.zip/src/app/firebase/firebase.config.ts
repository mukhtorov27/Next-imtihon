
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyBYo2qDxfWDY2BDFg6NFTF6-cbpQ9Tm9sk",
  authDomain: "next-mustaqil.firebaseapp.com",
  projectId: "next-mustaqil",
  storageBucket: "next-mustaqil.firebasestorage.app",
  messagingSenderId: "520719574711",
  appId: "1:520719574711:web:aac71128d48755b1e6cf32"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);