"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { db } from "@/app/firebase/firebase.config";
import { collection, getDocs, addDoc } from "firebase/firestore";
import "../homePage.css";

interface Product {
  id: string;
  name?: string;
  price?: number;
  description?: string;
  img?: string[];
}

export default function CartsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [orderingId, setOrderingId] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const q = collection(db, "products");
        const snap = await getDocs(q);
        const items = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        })) as Product[];
        setProducts(items);
      } catch (err) {
        console.error("Fetch products error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  async function handleOrder(product: Product) {
    if (!product) return;
    try {
      setOrderingId(product.id || "ordering");
      const payload = {
        name: product.name || "",
        img: product.img && product.img.length ? product.img[0] : "",
        price: product.price ?? 0,
        quantity: 1,
        personfullname: "",
        personnumber: "",
        personlocation: "",
        message: "",
        status: "pending",
        createdAt: new Date(),
      };
      await addDoc(collection(db, "buyurtma"), payload);
      alert("Buyurtma yuborildi");
    } catch (err) {
      console.error("Order failed:", err);
      alert("Buyurtma jo'natishda xatolik yuz berdi");
    } finally {
      setOrderingId(null);
    }
  }

  return (
    <div className="cartBox mb-32">
      <div className="carts justify-center">
        {loading ? (
          <div className="loading">Loading products...</div>
        ) : products.length === 0 ? (
          <div className="empty">No products found</div>
        ) : (
          products.map((product) => (
            <div
              key={product.id}
              className="cartSection"
              style={{ textDecoration: "none", color: "inherit" }}
            >
              <Link href={`/mahsulot/${product.id}`} className="cartClickable">
                <div className="cartImg">
                  <Image
                    src={
                      product.img && product.img.length
                        ? product.img[0]
                        : "/tent1.png"
                    }
                    alt={product.name || "Product"}
                    width={295}
                    height={200}
                    className="rounded-[20px]"
                    style={{ backgroundColor: "#E9F8EC" }}
                  />
                </div>
                <p className="cartName">{product.name || "No name"}</p>
              </Link>

              <div className="cartRating">rating</div>

              <div className="cartAddSection">
                <span>${product.price ?? "—"}</span>
                <div>
                  <button
                    aria-label="add-to-cart"
                    onClick={async (e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (orderingId) return;
                      await handleOrder(product);
                    }}
                    disabled={orderingId === product.id}
                    style={{
                      cursor:
                        orderingId === product.id ? "not-allowed" : "pointer",
                      border: "none",
                      background: "transparent",
                      padding: 6,
                    }}
                  >
                    <Image
                      src="/cartAdd.svg"
                      alt="Add to Cart"
                      width={16}
                      height={16}
                    />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
