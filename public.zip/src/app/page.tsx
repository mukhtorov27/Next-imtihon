// import Footer from "@/pages/homePage/footer";
// import Navbar from "@/pages/navbar";

// import Blog from "@/pages/homePage/blog";
import "@/app/homePage.css";
import HomePage from "./homePage/page";
// import Aloqa from "@/pages/homePage/aloqa";
// import Savat from "@/pages/homePage/savat";

// import Mahsulot from "@/pages/homePage/mahsulot";

function Home() {
  return (
    <div className="h-full">
      {/* <Navbar /> */}
      {/* <Mahsulot />  */}
      {/* <Savat /> */}
      {/* <Aloqa /> */}
      {/* <Footer /> */}
      <HomePage />
      {/* <Blog /> */}
    </div>
  );
}

export default Home;
